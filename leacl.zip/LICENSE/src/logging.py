'''
Paralysis C2 source
written by Null
'''

import logging

logging.basicConfig(
    level=logging.INFO,
    format="[PARALYSIS] [%(asctime)s] [%(levelname)s] %(message)s",
    datefmt="%H:%M:%S %d/%m/%Y"
)